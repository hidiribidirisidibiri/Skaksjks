package dev.elytraguard;

import java.util.ArrayDeque;
import java.util.EnumMap;
import java.util.UUID;

final class PlayerData {

    record Snap(long t, double x, double y, double z, double eyeY, float yaw, float pitch) {}

    final ArrayDeque<Snap> history = new ArrayDeque<>();
    final ArrayDeque<Long> attacks = new ArrayDeque<>();
    /** her check icin {vl, sonGuncelleme} */
    final EnumMap<CheckType, double[]> vl = new EnumMap<>(CheckType.class);

    UUID lastTarget;
    long lastAttackTime;
    float lastAttackYaw;

    void record(Snap s) {
        history.addLast(s);
        while (!history.isEmpty() && (s.t() - history.peekFirst().t() > 1500 || history.size() > 60)) {
            history.pollFirst();
        }
    }

    void reset() {
        history.clear();
        attacks.clear();
        lastTarget = null;
    }
}
