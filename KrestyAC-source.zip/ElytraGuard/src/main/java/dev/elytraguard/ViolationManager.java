package dev.elytraguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.List;

final class ViolationManager {

    private final ElytraGuard plugin;

    ViolationManager(ElytraGuard plugin) {
        this.plugin = plugin;
    }

    boolean enabled(CheckType t) {
        return plugin.getConfig().getBoolean("checks." + t.key + ".enabled", true);
    }

    /** @return vurusun iptal edilmesi gerekiyorsa true */
    boolean flag(Player p, PlayerData d, CheckType t, String detail) {
        FileConfiguration c = plugin.getConfig();
        String base = "checks." + t.key + ".";
        long now = System.currentTimeMillis();

        double[] v = d.vl.computeIfAbsent(t, k -> new double[]{0, now});
        double decay = c.getDouble("settings.decay-per-second", 0.15);
        v[0] = Math.max(0, v[0] - (now - v[1]) / 1000.0 * decay) + c.getDouble(base + "vl", 1.0);
        v[1] = now;

        String msg = c.getString("settings.alert-format", "%player% %check% %detail% %vl%")
                .replace("%player%", p.getName())
                .replace("%check%", t.display + (p.isGliding() ? " [Elytra]" : ""))
                .replace("%detail%", detail)
                .replace("%vl%", String.format("%.1f", v[0]));
        msg = ChatColor.translateAlternateColorCodes('&', msg);

        plugin.getLogger().info(ChatColor.stripColor(msg));
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("elytraguard.alerts") && plugin.alertsEnabled(staff)) {
                staff.sendMessage(msg);
            }
        }

        if (v[0] >= c.getDouble(base + "punish-vl", 10.0)) {
            List<String> cmds = c.getStringList(base + "commands");
            for (String cmd : cmds) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        ChatColor.translateAlternateColorCodes('&', cmd.replace("%player%", p.getName())));
            }
            v[0] = 0;
            return true;
        }
        return v[0] >= c.getDouble(base + "cancel-vl", 3.0);
    }
}
