ElytraGuard - Paper 1.19.4
Derleme: JDK 17+ (Java 25 de olur) ve Maven ile ->  mvn clean package
Cikan jar: target/ElytraGuard-1.0.0.jar  -> plugins/ klasorune at.
Komutlar: /eag reload | alerts | vl <oyuncu>
