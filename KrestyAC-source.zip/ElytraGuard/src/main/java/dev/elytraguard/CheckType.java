package dev.elytraguard;

enum CheckType {
    REACH("reach", "Reach"),
    ANGLE("angle", "KillAura (Angle)"),
    MULTI("multi", "KillAura (Multi)"),
    SNAP("snap", "KillAura (Snap)"),
    RATE("rate", "KillAura (Rate)");

    final String key;
    final String display;

    CheckType(String key, String display) {
        this.key = key;
        this.display = display;
    }
}
