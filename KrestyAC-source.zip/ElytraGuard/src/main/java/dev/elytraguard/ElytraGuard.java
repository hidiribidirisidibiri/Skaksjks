package dev.elytraguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ElytraGuard extends JavaPlugin implements CommandExecutor, TabCompleter {

    private final Map<UUID, PlayerData> data = new ConcurrentHashMap<>();
    private final Set<UUID> alertsOff = ConcurrentHashMap.newKeySet();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        ViolationManager vm = new ViolationManager(this);
        Bukkit.getPluginManager().registerEvents(new CombatListener(this, vm), this);
        var cmd = getCommand("elytraguard");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("ElytraGuard aktif.");
    }

    PlayerData data(Player p) {
        return data.computeIfAbsent(p.getUniqueId(), k -> new PlayerData());
    }

    void remove(Player p) {
        data.remove(p.getUniqueId());
        alertsOff.remove(p.getUniqueId());
    }

    boolean alertsEnabled(Player p) {
        return !alertsOff.contains(p.getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "help" : a[0].toLowerCase();
        switch (sub) {
            case "reload" -> {
                reloadConfig();
                s.sendMessage(ChatColor.GREEN + "ElytraGuard config yenilendi.");
            }
            case "alerts" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage("Sadece oyuncular.");
                    return true;
                }
                if (alertsOff.remove(p.getUniqueId())) {
                    p.sendMessage(ChatColor.GREEN + "Uyarilar acildi.");
                } else {
                    alertsOff.add(p.getUniqueId());
                    p.sendMessage(ChatColor.YELLOW + "Uyarilar kapatildi.");
                }
            }
            case "vl" -> {
                if (a.length < 2) {
                    s.sendMessage(ChatColor.RED + "/eag vl <oyuncu>");
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(ChatColor.RED + "Oyuncu bulunamadi.");
                    return true;
                }
                PlayerData d = data(t);
                s.sendMessage(ChatColor.GOLD + t.getName() + " VL:");
                for (CheckType ct : CheckType.values()) {
                    double[] v = d.vl.get(ct);
                    s.sendMessage(ChatColor.GRAY + " " + ct.display + ": " + ChatColor.WHITE
                            + String.format("%.1f", v == null ? 0 : v[0]));
                }
            }
            default -> s.sendMessage(ChatColor.YELLOW + "/eag reload | alerts | vl <oyuncu>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("reload", "alerts", "vl")) if (x.startsWith(a[0].toLowerCase())) out.add(x);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("vl")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        return out;
    }
}
