package dev.elytraguard;

import org.bukkit.GameMode;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

final class CombatListener implements Listener {

    private final ElytraGuard plugin;
    private final ViolationManager vm;

    CombatListener(ElytraGuard plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    // ---------- Konum gecmisi (lag compensation) ----------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        Player p = e.getPlayer();
        plugin.data(p).record(new PlayerData.Snap(System.currentTimeMillis(),
                to.getX(), to.getY(), to.getZ(), to.getY() + p.getEyeHeight(), to.getYaw(), to.getPitch()));
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        plugin.data(e.getPlayer()).reset();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.remove(e.getPlayer());
    }

    // ---------- Vurus kontrolleri ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!(e.getDamager() instanceof Player p)) return;

        Entity target = e.getEntity();
        FileConfiguration c = plugin.getConfig();
        PlayerData d = plugin.data(p);
        long now = System.currentTimeMillis();

        // Durum takibi her zaman guncellenir
        d.attacks.addLast(now);
        while (!d.attacks.isEmpty() && now - d.attacks.peekFirst() > 1000) d.attacks.pollFirst();
        java.util.UUID prevTarget = d.lastTarget;
        long prevTime = d.lastAttackTime;
        float prevYaw = d.lastAttackYaw;
        d.lastTarget = target.getUniqueId();
        d.lastAttackTime = now;
        d.lastAttackYaw = p.getLocation().getYaw();

        if (exempt(p)) return;
        boolean glide = p.isGliding();
        if (c.getBoolean("settings.only-elytra", false) && !glide) return;

        long window = Math.max(120, Math.min(600, p.getPing() + 100));
        double[] m = measure(p, d, target, now, window);
        double reach = m[0], angle = m[1];
        boolean cancel = false;

        // 1) Reach
        if (vm.enabled(CheckType.REACH)) {
            double allowed = c.getDouble("checks.reach.max-reach", 3.0)
                    + c.getDouble("checks.reach.tolerance", 0.30)
                    + (glide ? c.getDouble("checks.reach.elytra-bonus", 0.25) : 0);
            if (reach > allowed) {
                cancel |= vm.flag(p, d, CheckType.REACH,
                        String.format("%.2f > %.2f, ping=%d", reach, allowed, p.getPing()));
            }
        }

        // 2) Aci
        if (vm.enabled(CheckType.ANGLE)) {
            double maxAngle = c.getDouble("checks.angle.max-angle", 65.0);
            if (reach > c.getDouble("checks.angle.min-distance", 1.2) && angle > maxAngle) {
                cancel |= vm.flag(p, d, CheckType.ANGLE, String.format("aci=%.1f", angle));
            }
        }

        // 3) Multi-aura
        if (vm.enabled(CheckType.MULTI) && prevTarget != null
                && !prevTarget.equals(target.getUniqueId())
                && now - prevTime < c.getLong("checks.multi.window-ms", 60)) {
            cancel |= vm.flag(p, d, CheckType.MULTI, "dt=" + (now - prevTime) + "ms");
        }

        // 4) Ani bakis donusu
        if (vm.enabled(CheckType.SNAP) && prevTarget != null
                && !prevTarget.equals(target.getUniqueId())
                && now - prevTime < c.getLong("checks.snap.window-ms", 200)) {
            double delta = Math.abs(wrap(p.getLocation().getYaw() - prevYaw));
            if (delta > c.getDouble("checks.snap.min-yaw-delta", 110.0)) {
                cancel |= vm.flag(p, d, CheckType.SNAP, String.format("yaw=%.0f dt=%dms", delta, now - prevTime));
            }
        }

        // 5) Vurus hizi
        if (vm.enabled(CheckType.RATE)) {
            int max = c.getInt("checks.rate.max-hits-per-second", 20);
            if (d.attacks.size() > max) {
                cancel |= vm.flag(p, d, CheckType.RATE, d.attacks.size() + " hit/s");
            }
        }

        if (cancel) e.setCancelled(true);
    }

    private boolean exempt(Player p) {
        FileConfiguration c = plugin.getConfig();
        if (p.hasPermission("elytraguard.bypass")) return true;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return true;
        if (p.getPing() > c.getInt("settings.max-ping", 450)) return true;
        return Bukkit.getTPS()[0] < c.getDouble("settings.min-tps", 17.0);
    }

    /**
     * Gecmis konumlar (ping penceresi) uzerinden en yumusak (en dusuk) menzil ve aciyi hesaplar.
     * Boylece lag nedeniyle meşru vuruslar flaglenmez.
     * @return {minReach, minAngle}
     */
    private double[] measure(Player p, PlayerData ad, Entity t, long now, long window) {
        // Saldirgan: su anki + gecmis gozler (elytra'da goz yuksekligi 0.4 oldugu icin eyeY kayitli)
        List<PlayerData.Snap> eyes = new ArrayList<>();
        Location pl = p.getLocation();
        eyes.add(new PlayerData.Snap(now, pl.getX(), pl.getY(), pl.getZ(),
                pl.getY() + p.getEyeHeight(), pl.getYaw(), pl.getPitch()));
        for (PlayerData.Snap s : ad.history) if (now - s.t() <= window) eyes.add(s);

        // Hedef: su anki + (oyuncuysa) gecmis hitbox'lar
        BoundingBox cur = t.getBoundingBox();
        List<BoundingBox> boxes = new ArrayList<>();
        boxes.add(cur.clone().expand(0.1));
        if (t instanceof Player tp) {
            Location tl = tp.getLocation();
            for (PlayerData.Snap s : plugin.data(tp).history) {
                if (now - s.t() > window) continue;
                boxes.add(cur.clone().shift(s.x() - tl.getX(), s.y() - tl.getY(), s.z() - tl.getZ()).expand(0.1));
            }
        }

        double minReach = Double.MAX_VALUE;
        double minAngle = 180;
        for (PlayerData.Snap s : eyes) {
            Vector dir = direction(s.yaw(), s.pitch());
            for (BoundingBox b : boxes) {
                double cx = clamp(s.x(), b.getMinX(), b.getMaxX());
                double cy = clamp(s.eyeY(), b.getMinY(), b.getMaxY());
                double cz = clamp(s.z(), b.getMinZ(), b.getMaxZ());
                double dx = cx - s.x(), dy = cy - s.eyeY(), dz = cz - s.z();
                double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                minReach = Math.min(minReach, dist);
                if (dist < 1e-6) {
                    minAngle = 0;
                } else {
                    double cos = clamp(dir.dot(new Vector(dx, dy, dz)) / dist, -1, 1);
                    minAngle = Math.min(minAngle, Math.toDegrees(Math.acos(cos)));
                }
            }
        }
        return new double[]{minReach, minAngle};
    }

    private static Vector direction(float yaw, float pitch) {
        double y = Math.toRadians(yaw), pt = Math.toRadians(pitch);
        double xz = Math.cos(pt);
        return new Vector(-xz * Math.sin(y), -Math.sin(pt), xz * Math.cos(y));
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static double wrap(double deg) {
        deg %= 360;
        if (deg > 180) deg -= 360;
        if (deg < -180) deg += 360;
        return deg;
    }
}
